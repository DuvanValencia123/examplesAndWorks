<?php 
$sumando1 = strtolower($_POST["Number1"]);
$sumando2 = strtolower($_POST["Number2"]);

	$arr = array(
			'one' => 1,
			'two' => 2,
			'three' => 3,
			'fourt' => 4,
			'five' => 5,
			'six' => 6,
			'seven' => 7,
			'eight' => 8,
			'nine' => 9,
		    'ten' => 10,
		    'eleven' => 11,
		    'twelve' => 12,
		    'thirteen' => 13,
		    'fourteen' => 14,
		    'fifteen' => 15,
		    'sixteen' => 16,
		    'seventeen' => 17,
		    'eighteen' => 18,
		    'nineteen' => 19,
		    'twenty' => 20
		    );

   $numberInLetter = array(
			  '1' => 'one',
			  '2' => 'two',
			  '3' => 'three',
			  '4' => 'fourt',
			  '5' => 'five',
			  '6' => 'six' ,
			  '7' => 'seven',
			  '8' => 'eight',
			  '9' => 'nine',
		     '10' => 'ten',
		     '11' => 'eleven',
		     '12' => 'twelve',
		     '13' => 'thirteen',
		     '14' => 'fourteen',
		     '15' => 'fifteen',
		     '16' => 'sixteen',
		     '17' => 'seventeen',
		     '18' => 'eighteen',
		     '19' => 'nineteen',
		     '20' => 'twenty',
		     '21' => 'twenty one',
		     '22' => 'twenty two',
		     '23' => 'twenty three',
		     '24' => 'twenty fourt',
		     '25' => 'twenty five',
		     '26' => 'twenty six',
		     '27' => 'twenty seven',
		     '28' => 'twenty eight',
		     '29' => 'twenty nine',
		     '30' => 'thirty'
		    );
function LookingSame($sumando,$arr){
    foreach ($arr as $numeros => $valor) {
		if($sumando == $numeros){ return "true"; }
    }
}

$validSumando1 = LookingSame($sumando1,$arr);
$validSumando2 = LookingSame($sumando2,$arr);

if( $validSumando2 == 'true' && $validSumando1 == 'true' ){
  $result = $arr[$sumando1] + $arr[$sumando2];
   echo $numberInLetter[$result];
}

else if($validSumando1 != 'true' || $validSumando2 != 'true'){
   echo 'Ingresa un numero válido';
}

 ?>